
export default new Map([
["src/content/articulos/la-ventanilla-y-el-algoritmo.mdoc", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Farticulos%2Fla-ventanilla-y-el-algoritmo.mdoc&astroContentModuleFlag=true")],
["src/content/articulos/esto-es-una-prueba.mdoc", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Farticulos%2Festo-es-una-prueba.mdoc&astroContentModuleFlag=true")]]);
		