---
title: "Promesa pública en tiempos de indicador"
description: "Cuando medir devora el fin: política en régimen de métricas."
date: 2026-01-20
section: "Ensayos"
temas: ["Política"]
draft: false
---

Texto...
