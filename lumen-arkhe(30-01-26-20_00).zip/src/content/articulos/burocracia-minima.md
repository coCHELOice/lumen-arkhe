---
title: "Burocracia mínima: el precio de la continuidad"
description: "Fricción visible vs densidad opaca: una tesis para el siglo administrativo."
date: 2026-01-23
section: "Ensayos"
temas: ["Burocracia"]
draft: false
---

Aquí va el texto del artículo.  
Puedes escribir largo, con subtítulos:

## 1. El precio de la continuidad

Texto...
